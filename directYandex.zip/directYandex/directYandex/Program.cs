﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Text.RegularExpressions;
using System.Web;
using System.Threading;
using System.Net;
using System.Threading;

namespace directYandex
{
    class Program
    {
        public struct oneAd
        {
            public string title;
            public string text;
            public string domain;
            public string keyword;
            public int titleLength;
            public int textLength;
        }
        static List<oneAd> allAds = new List<oneAd>();
        static string category = "Корм для собак";
        static void Main(string[] args)
        {
            if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + "files/" + category))
            {
                Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "files/" + category);
            }
            
            
            string PathKwlist = "kwlist.txt";
            StreamReader kwfile = new StreamReader(@PathKwlist);
            string kwline;
            while ((kwline = kwfile.ReadLine()) != null)
            {
                int p = 1;
                string html;

                do
                {
                label1:
                    html = getPage("http://direct.yandex.ru/search?&text=" + HttpUtility.UrlEncode(kwline) + "&page=" + p);
                    Console.WriteLine(p);

                    /*Поиск каптчи*/
                    if (html.IndexOf("Контрольные цифры") > -1)
                    {
                        Console.WriteLine("Ожидание ввода каптчи! (5sec)");
                        Thread.Sleep(5000);
                        goto label1;
                    }
                        
                    /**/
                    string patternTitle = "'title':(.*)";
                    string patternText = "'text':(.*)";
                    string patternDomain = "'domain':(.*)";
                    //Match match in Regex.Matches(html, pattern, RegexOptions.Multiline)
                    MatchCollection matchTitle = Regex.Matches(html, patternTitle, RegexOptions.Multiline);
                    MatchCollection matchText = Regex.Matches(html, patternText, RegexOptions.Multiline);
                    MatchCollection matchDomain = Regex.Matches(html, patternDomain, RegexOptions.Multiline);

                    for (int i = 0; i < matchTitle.Count; i++)
                    {
                        string title, text, domain;
                        title = matchTitle[i].Value.Replace("'title': '", "").Replace("',", "");
                        text = matchText[i].Value.Replace("'text': '", "").Replace("',", "");
                        domain = matchDomain[i].Value.Replace("'domain': '", "").Replace("',", "");
                        Console.WriteLine(title);
                        Console.WriteLine(text);
                        Console.WriteLine(domain);
                        Console.WriteLine("Запрос: " + kwline);
                        Console.WriteLine("Заголовок: " + title.Length + " сим.");
                        Console.WriteLine("Текст: " + text.Length + " сим.");
                        Console.WriteLine("Домен: " + domain);
                        Console.WriteLine("*****************************************************************");

                        if (!checkDuplicate(title, text, domain))
                        {
                            oneAd objava = new oneAd();
                            objava.title = title;
                            objava.text = text;
                            objava.domain = domain;
                            objava.keyword = kwline;
                            objava.titleLength = title.Length;
                            objava.textLength = text.Length;

                            allAds.Add(objava);
                            writeFile(title, text, domain, kwline, title.Length, text.Length);

                        }
                    }                    
                    p++;
                    Thread.Sleep(2000);
                } while (nextPage(html));

                Console.WriteLine(allAds.Count());
                //Console.ReadKey();
            }            
        }
        static bool nextPage(string html)
        {
            if (html.IndexOf("b-pager__next") > -1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        static string getPage(string page)
        {
            WebRequest reqGET = WebRequest.Create(page);
            WebResponse resp = reqGET.GetResponse();
            Stream stream = resp.GetResponseStream();
            StreamReader sr = new StreamReader(stream);
            string html = sr.ReadToEnd();
            return html;
        }

        static bool checkDuplicate(string titled, string textd, string domaind)
        {
            foreach (oneAd ads in allAds)
            {
                if (ads.title == titled && ads.text == textd && ads.domain == domaind)
                    return true;
            }

            return false;
        }
        static void writeFile(string title, string text, string domain, string kwline, int titleLength, int textLength)
        {
            string[] lines = {
                                 "<h1>" + category + "</h1>",
                                 "<h2>" + title + "</h2>",
                                 "<p>" + text + "</p>"
                             };
            File.WriteAllLines(AppDomain.CurrentDomain.BaseDirectory + "files/" + category + "/" + kwline.Replace(" ", "-") + "-" + domain + ".html", lines);
        }
    }
}
